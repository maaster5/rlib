library(data.table)

#setwd('d:/Dane/LakomyP/Rprojects/practice/conditional_panel___11/app__11_DataTable/')
file_path<-"d:/Dane/LakomyP/Rprojects/practice/conditional_panel___11/data/flights_2014.csv"
df = fread(file_path)
print(df)


nrow(df)
names(df)
head(df,n = 2)

is.data.table(df)

df1=df[,origin] # returns a vector
df1

df1=df[,.(origin)] # returns a data.table
df1

df1=df[,c("origin")] # returns a data.frame
df1


dat2 = df[,2]
dat2

df
dat2A = df[,c(1:4)]
dat2A

dat3 = df[, .(origin, year, month, dep_time)]
dat3

dat6 = df[, !c("origin", "year", "month")]
dat6


dat7 = df[,names(df) %like% "dep"]
dat7

# renaming column names:
dat6 = df[, !c("origin", "year", "month")]
names(dat6)
setnames(dat6, c("dest"), c("destination"))
names(dat6)
setnames(dat6, c("destination"), c("dest"))
names(dat6)


dat7 = df[, !c("year", "month")]
names(dat7)
setnames(dat7, c("dest", "origin"), c("destination", "origin_of_flight"))
names(dat7)
setnames(dat7, c("destination"), c("dest"))
setnames(dat7, c("origin_of_flight"), c("origin"))
names(dat7)


# Filtering data
dat1=df[origin=="JFK"]
dat1

dat2=df[origin %in% c("JFK", "LGA")]
dat2

dat3=df[!origin %in% c("JFK", "LGA")]
dat3

dat4distinct=unique(df[,.(carrier)])
dat4distinct

dat4=df[origin=="JFK" & carrier=="HA"]
dat4


#indexing for searching
system.time(df[origin %in% c("JFK", "LGA")])
setkey(df, origin)
system.time(df[c("JFK", "LGA")])


dat1A=df
dat1A
setkey(dat1A, origin, dest)

p1=dat1A[.("JFK", "MIA")]
# equvalent to:
p2=dat1A[origin=="JFK" & dest == "MIA"]

print("p1 :")
p1
print("p2 :")
p2

# sorting data
dat2=df
dat2
dat2Ord=setorder(dat2, origin) #ascending as default
dat2Ord_desc=setorder(dat2, -origin)
dat2A=setorder(dat2, origin, -month)
dat2A

dat3=df
dat3
dat3[,dep_shed:=dep_time - dep_delay]
dat3
