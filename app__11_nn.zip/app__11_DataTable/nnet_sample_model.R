

#library(MASS)
library(neuralnet)

data <- Boston
apply(data,2,function(x) sum(is.na(x)))


print(data)

# https://www.r-bloggers.com/2015/09/fitting-a-neural-network-in-r-neuralnet-package/

maxs <- apply(data, 2, max)
print(maxs)
mins <- apply(data, 2, min)
print(mins)

scaled_mins <- as.data.frame(scale(data, center = mins, scale = maxs - mins))
scaled_std_dev <- as.data.frame(scale(data, center = TRUE, scale = TRUE))

print(scaled_mins)


split_fact<-0.75

index <- sample(1:nrow(data),round(split_fact*nrow(data)))
train <- data[index,]
test <- data[-index,]
lm.fit <- glm(medv~., data=train)
summary(lm.fit)
pr.lm <- predict(lm.fit,test)
MSE.lm <- sum((pr.lm - test$medv)^2)/nrow(test)


#Akaike Information Criterion:
# https://www.scribbr.com/statistics/akaike-information-criterion/

set.seed(1234)



index <- sample(1:nrow(data),round(split_fact*nrow(data)))
train_ <- scaled_mins[index,]
test_ <- scaled_mins[-index,]


n <- names(train_)
f <- as.formula(paste("medv ~", paste(n[!n %in% "medv"], collapse = " + ")))
nn <- neuralnet(f,data=train_,hidden=c(6,3),linear.output=T)

plot(nn)


pr.nn <- compute(nn,test_[,1:13])
pr.nn_ <- pr.nn$net.result*(max(data$medv)-min(data$medv))+min(data$medv)
test.r <- (test_$medv)*(max(data$medv)-min(data$medv))+min(data$medv)
MSE.nn <- sum((test.r - pr.nn_)^2)/nrow(test_)

 
sprintf('NN model LSE: %f,  Lin. model MSE: %f', MSE.nn,  MSE.lm)


par(mfrow=c(1,2))

plot(test$medv,pr.nn_,col='red',main='Real vs predicted NN',pch=18,cex=0.75)
abline(0,1,lwd=2)
legend('bottomright',legend='NN',pch=18,col='red', bty='n')


plot(test$medv,pr.lm,col='blue',main='Real vs predicted lin. model',pch=18, cex=0.75)
abline(0,1,lwd=2)
legend('bottomright',legend='LM',pch=18,col='blue', bty='n', cex=.95)




